import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profileandvisibility',
  templateUrl: './profileandvisibility.component.html',
  styleUrls: ['./profileandvisibility.component.css']
})
export class ProfileandvisibilityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
