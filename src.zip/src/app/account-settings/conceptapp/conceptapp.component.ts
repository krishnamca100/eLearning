import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conceptapp',
  templateUrl: './conceptapp.component.html',
  styleUrls: ['./conceptapp.component.css']
})
export class ConceptappComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
