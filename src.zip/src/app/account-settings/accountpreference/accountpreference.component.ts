import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountpreference',
  templateUrl: './accountpreference.component.html',
  styleUrls: ['./accountpreference.component.css']
})
export class AccountpreferenceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
